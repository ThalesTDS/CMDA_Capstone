import os
import cv2
from VGG11.env import PREPRO_DIR, DOWNLOAD_DIR
import numpy as np
import face_recognition as fr
from tqdm import tqdm

real_SUBPATH = os.path.join('real','')
fake_SUBPATH = os.path.join('fake', '')

subpath = {'real': real_SUBPATH,
           'fake': fake_SUBPATH}



def extract_frames(video_path):
    """Given the video path, extract every frame from video."""

    reader = cv2.VideoCapture(video_path)
    frameCount = int(reader.get(cv2.CAP_PROP_FRAME_COUNT))
    frameWidth = int(reader.get(cv2.CAP_PROP_FRAME_WIDTH))
    frameHeight = int(reader.get(cv2.CAP_PROP_FRAME_HEIGHT))

    buf = np.empty((frameCount, frameHeight, frameWidth, 3), np.dtype('uint8'))

    frame_num = 0
    while reader.isOpened():
        success, image = reader.read()
        if not success:
            break
        buf[frame_num] = image
        frame_num += 1
    reader.release()

    return buf

def crop_faces(offset=1, x_expand=1.5, y_expand=1.8):
    np.random.seed(0)

    video_path = '../video/keyFrames/keyFrameVideo/keyFrameVideo.mp4'

    # extract frames from videos
    frames = extract_frames(video_path)

    # if video has the number of frames <= 1, skip
    if len(frames) <= 1:
        print('Error:No Frames found')
        return    
    
    reader = cv2.VideoCapture(video_path)
    frameCount = int(reader.get(cv2.CAP_PROP_FRAME_COUNT))
    sel_indices = np.arange(frameCount-1)
    reader.release()

    print('frameCount: ' + str(frameCount))

    for i, idx in enumerate(sel_indices):
        saved_path = os.path.join('../video/keyFrames', 'cropped_faces', str(idx))

        # face detection
        
        face_locations = fr.face_locations(frames[idx])
        

        # extract the first person in the frame
        if len(face_locations) >= 1:
            top, right, bottom, left = face_locations[0]
            b, h, w, c = frames.shape

            # cropping area
            top = max(0, int((bottom+top)//2 - (bottom-top)//2*y_expand))  # max(0, int(top-1.5*expand))
            right = min(w-1, int((right+left)//2 + (right-left)//2*x_expand))  # min(w-1, right+expand)
            bottom = min(h-1, int((bottom+top)//2 + (bottom-top)//2*y_expand))  # min(h-1, int(bottom+1.5*expand))
            left = max(0, int((right+left)//2 - (right-left)//2*x_expand))  # max(0, left-expand)

            if not os.path.exists(saved_path):
                os.makedirs(saved_path)

            # save consecutive frames
            cv2.imwrite(os.path.join(saved_path, '1.png'),
                        cv2.resize(frames[idx, top:bottom, left:right], (256, 256)))
            cv2.imwrite(os.path.join(saved_path, '2.png'),
                        cv2.resize(frames[idx+offset, top:bottom, left:right], (256, 256)))



def crop_face(dataset, compression, num_frames, offset, x_expand, y_expand, continueous):
    """Save consecutive frames.
    
    Params:
    dataset: str, must in {'youtube', 'NeuralTextures', 'FaceSwap', 'Face2Face', 'Deepfakes'}
    compression: str, must in {'raw', 'c23', 'c40'}
    num_frames: int, the number of frames to be sampled
    offset: int, the offset between two frames
    x_expand: float, expand the cropping area of x_axis
    y_expand: float, expand the cropping area of y_axis
    """

    np.random.seed(0)
    assert dataset in subpath

    path = os.path.join(DOWNLOAD_DIR,subpath[dataset])
    video_name_list = os.listdir(path)

    pbar = tqdm(video_name_list)
    for video_name_ext in pbar:
        pbar.set_description('[{}]'.format(dataset))

        video_name = video_name_ext.split('.')[0]
        video_path = os.path.join(path, video_name_ext)

        if os.path.exists(os.path.join(path, subpath[dataset], video_name)):
            continue

        # extract frames from videos
        frames = extract_frames(video_path)

        # if video has the number of frames <= 1, skip
        if len(frames) <= 1:
            continue

        
        if not continueous: # indices to randomly sampled frames
            sel_indices = np.random.choice(len(frames)-1, min(num_frames, len(frames)-1), replace=False)
        else: # indices to first num_frame frames
            reader = cv2.VideoCapture(video_path)
            frameCount = int(reader.get(cv2.CAP_PROP_FRAME_COUNT))
            sel_indices = np.arange(frameCount-1)
            reader.release()

        for i, idx in enumerate(sel_indices):
            saved_path = os.path.join(path, 'frames', video_name, str(idx))

            # face detection
            
            face_locations = fr.face_locations(frames[idx])
            

            # extract the first person in the frame
            if len(face_locations) >= 1:
                top, right, bottom, left = face_locations[0]
                b, h, w, c = frames.shape

                # cropping area
                top = max(0, int((bottom+top)//2 - (bottom-top)//2*y_expand))  # max(0, int(top-1.5*expand))
                right = min(w-1, int((right+left)//2 + (right-left)//2*x_expand))  # min(w-1, right+expand)
                bottom = min(h-1, int((bottom+top)//2 + (bottom-top)//2*y_expand))  # min(h-1, int(bottom+1.5*expand))
                left = max(0, int((right+left)//2 - (right-left)//2*x_expand))  # max(0, left-expand)

                if not os.path.exists(saved_path):
                    os.makedirs(saved_path)

                # save consecutive frames
                cv2.imwrite(os.path.join(saved_path, '1.png'),
                            cv2.resize(frames[idx, top:bottom, left:right], (256, 256)))
                cv2.imwrite(os.path.join(saved_path, '2.png'),
                            cv2.resize(frames[idx+offset, top:bottom, left:right], (256, 256)))


def crop_dataset():
    for key, val in subpath.items():
            crop_face(key, 'raw', num_frames=20, offset=1, x_expand=1.5, y_expand=1.8, continueous=False) # used for CNN model

if __name__ == '__main__':
    pass
    
