import os
import torch
from PIL import Image
from torchvision.transforms import Compose, Resize, CenterCrop, ToTensor, Normalize
import matplotlib.pyplot as plt
import re
from VGG11.dataloader.dataloader import get_loader

def atoi(text):
    """Helper function to convert text to integers where applicable."""
    return int(text) if text.isdigit() else text

def natural_keys(text):
    """
    Sorting helper function to ensure natural order sorting (e.g., idd_9 comes before idd_10).
    This will split the directory names into parts and sort them numerically where applicable.
    """
    return [atoi(c) for c in re.split(r'(\d+)', text)]

def load_frames_from_directory(directory='../video/keyFrames/cropped_faces'):
    """
    Load all frames from the given directory, excluding any files named 'farnback_flow.png'.
    
    Args:
    directory: Path to the main directory containing subdirectories with frames.
    
    Returns:
    frames: List of frames as tensors, sorted based on natural directory order (idd_9 before idd_10).
    """
    
    frames = []
    transform = Compose([CenterCrop(256), Resize(299), ToTensor(), 
                         Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])])

    # Get all subdirectories and sort them based on natural order
    subdirs = sorted([os.path.join(directory, d) for d in os.listdir(directory) if os.path.isdir(os.path.join(directory, d))],
                     key=natural_keys)

    # Loop through each sorted subdirectory
    for subdir in subdirs:
        for file in sorted(os.listdir(subdir)):
            if file.endswith('.png') and file != 'farnback_flow.png':
                frame_path = os.path.join(subdir, file)
                frame = Image.open(frame_path).convert('RGB')  # Ensure it's in RGB mode
                frame = transform(frame)  # Apply preprocessing transforms
                frames.append(frame)
    
    return frames

def load_frames_from_directory_VGG(directory='../video/keyFrames/cropped_faces'):
    """
    Load all frames from the given directory, excluding any files named 'farnback_flow.png'.
    
    Args:
    directory: Path to the main directory containing subdirectories with frames.
    
    Returns:
    frames: List of frames as tensors, sorted based on natural directory order (idd_9 before idd_10).
    """
    
    frames = []
    transform = Compose([CenterCrop(256), Resize(256), ToTensor(), 
                         Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225])])

    # Get all subdirectories and sort them based on natural order
    subdirs = sorted([os.path.join(directory, d) for d in os.listdir(directory) if os.path.isdir(os.path.join(directory, d))],
                     key=natural_keys)

    # Loop through each sorted subdirectory
    for subdir in subdirs:
        for file in sorted(os.listdir(subdir)):
            if file.endswith('.png') and file == 'farnback_flow.png':
                frame_path = os.path.join(subdir, file)
                frame = Image.open(frame_path).convert('RGB')  # Ensure it's in RGB mode
                frame = transform(frame)  # Apply preprocessing transforms
                frames.append(frame)
    
    return frames

def evaluate_frameVGG(frame, model):
    """Evaluate a single frame using a deepfake detection model with a single-class output."""
    frame = frame.unsqueeze(0).to(torch.device('cpu'))  # Add batch dimension and move to GPU
    model.eval()  # Set model to evaluation mode
    with torch.no_grad():  # Disable gradient computation
        output = model(frame)
        
        # For a single-class output, the output itself is the logit or probability for the "real" class
        # Apply sigmoid to get probability if the output is a logit
        probability = torch.sigmoid(output)
        
        # Make binary decision: 1 if probability >= 0.5 (real), else 0 (fake)
        predicted_label = (probability >= 0.5).float()
        
        # Return the predicted label and its confidence (the probability itself)
        return predicted_label.item(), probability.item()

def evaluate_frame(frame, model):
    """Evaluate a single frame using the deepfake detection model."""
    frame = frame.unsqueeze(0).to(torch.device('cpu'))  # Add batch dimension
    model.eval()  # Set model to evaluation mode
    with torch.no_grad():  # Disable gradient computation
        output = model(frame)
        probabilities = torch.softmax(output, dim=1)
        confidence, predicted_label = torch.max(probabilities, 1)
    return predicted_label.item(), confidence.item()

def deepfake_detection_on_video(model,mode):
    if mode == 'VGG':
        frames = get_loader('test', batch_size=1, shuffle=True, num_data=-1, path='../video/')
        frames = frames.dataset
    else:
        frames = load_frames_from_directory()
    """
    Process all frames from the video, evaluate them using the deepfake detection model, 
    and determine the final label based on majority voting.
    
    Args:
    frames: List of frames to evaluate.
    model: The deepfake detection model.
    
    Returns:
    final_label: Majority label (1 for real, 0 for fake).
    confidence: Percentage of frames classified as the final label.
    """
    frame_labels = []
    confidences = []

    for frame in frames:
        if mode == 'VGG':
            frame = frame[0]
        # Evaluate each frame
        if mode == 'VGG':
             label, confidence = evaluate_frameVGG(frame, model)
        else:
            label, confidence = evaluate_frame(frame, model)
        frame_labels.append(label)
        confidences.append(confidence)

    
    # Perform majority voting, 0 for fake, 1 for real
    majority_label = max(set(frame_labels), key=frame_labels.count)
    
    # Calculate percentage confidence for the final label
    label_count = frame_labels.count(majority_label)
    confidence_percentage = (label_count / len(frame_labels)) * 100
    
    if mode == 'VGG':
        if majority_label == 1:
            majority_label = 0
        else:
            majority_label = 1

    return majority_label, confidence_percentage

def plot_confidence_percentage(label, confidence_percentage):
    """Plot the percentage confidence of the final label."""
    labels = ['Fake','Real']
    plt.bar(labels[label], confidence_percentage, color=['green' if label == 0 else 'red'])
    plt.ylim(0, 100)
    plt.title(f'Confidence Percentage: {confidence_percentage:.2f}%')
    plt.ylabel('Confidence (%)')
    plt.show()


